# Sükut Nöqtəsi: Android layihəsi

Bu layihə oyunu (HTML5) tam ekranlı, internetsiz Android tətbiqinə çevirir. Oyun `app/src/main/assets/index.html` faylındadır.

Qeyd: layihə bu söhbətdə yazılıb, amma APK-ya yığılıb sınaqdan keçirilməyib (yazıldığı mühitdə Android SDK yükləmək mümkün olmayıb). Yığılma zamanı xəta çıxsa, xəta mətnini göndər, düzəldərik.

## Yol 1: Android Studio ilə

1. Android Studio-nu aç və **Open** ilə bu qovluğu seç.
2. Gradle sinxronizasiyasının bitməsini gözlə (ilk dəfə bir neçə dəqiqə çəkə bilər).
3. Menyudan **Build > Build Bundle(s) / APK(s) > Build APK(s)** seç.
4. Hazır fayl burada olacaq: `app/build/outputs/apk/debug/app-debug.apk`

## Yol 2: Kompüterə heç nə quraşdırmadan (GitHub ilə)

1. GitHub-da yeni repozitoriya yarat və bu qovluğun içindəkiləri ora yüklə.
2. Repozitoriyada **Actions** bölməsinə keç, **APK yığ** workflow-unu seç və **Run workflow** düyməsinə bas.
3. Bir neçə dəqiqədən sonra işin səhifəsindəki **Artifacts** hissəsindən `sukut-noqtesi-apk` faylını endir (içində `app-debug.apk` var).

## Telefona quraşdırma

1. `app-debug.apk` faylını telefona köçür.
2. Faylı aç. Telefon icazə istəsə, "naməlum mənbədən quraşdırma" icazəsini ver.
3. Quraşdırıb "Sükut Nöqtəsi" ikonu ilə aç.

## Oyunu dəyişmək

Bütün oyun kodu `app/src/main/assets/index.html` faylındadır. Orada düzəliş edib APK-nı yenidən yığ.
